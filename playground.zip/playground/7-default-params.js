const greeter = (name = 'user') => {
    console.log('Hello ' + name);
}

greeter('Andy')
greeter()
