import React from 'react';
import Col from 'react-bootstrap/Col';
import ListGroup from 'react-bootstrap/ListGroup';
import ListGroupItem from 'react-bootstrap/ListGroupItem';
const PokeList = ({listOfPokemon}) => {

    let pokemon = listOfPokemon.map((creature) => {
        return (
            <Col sm={6} md={4} key={creature.name}>
                <ListGroupItem className="Pokelist-item">{creature.name}</ListGroupItem>
            </Col>
        );
    })
   
    return(
        <ListGroup>
            {pokemon}
        </ListGroup>
    );
}

export default PokeList;